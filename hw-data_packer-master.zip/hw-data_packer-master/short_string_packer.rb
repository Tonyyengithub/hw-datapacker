class ShortStringPacker
  ## Packs a short string into a Fixnum
  # Arguments:
  #   str - String object
  # Returns: a Fixnum object
  def self.pack(str)
    # IMPLEMENT THIS METHOD
  end

  ## Unpacks a Fixnum from pack() method into a short string
  # Arguments:
  #   packed - a Fixnum object
  # Returns: a String object
  def self.unpack(packed)
    # IMPLEMENT THIS METHOD
  end
end
